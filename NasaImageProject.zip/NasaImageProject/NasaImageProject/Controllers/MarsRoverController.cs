﻿using Microsoft.AspNetCore.Mvc;
using NasaImageProject.Services;

namespace NasaImageProject.Controllers
{
    public class MarsRoverController : Controller
    {
        private readonly IMarsRoverService _marsRoverService;

        public MarsRoverController(IMarsRoverService marsRoverService)
        {
            _marsRoverService = marsRoverService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> SearchByDate(DateTime date)
        {
            var photos = await _marsRoverService.GetPhotosByDateAsync(date);
            return View("Result", photos);
        }
    }
}
