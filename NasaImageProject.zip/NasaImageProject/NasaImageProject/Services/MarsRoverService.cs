﻿using NasaImageProject.Model;
using Newtonsoft.Json;

namespace NasaImageProject.Services
{
    public class MarsRoverService : IMarsRoverService
    {
        private readonly HttpClient _httpClient;
        public MarsRoverService(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri("https://images-api.nasa.gov/");
        }

        public async Task<List<PhotoItem>> GetPhotosByDateAsync(DateTime date)
        {
            var formattedDate = date.ToString("yyyy-MM-dd");
            var url = $"/search?q={formattedDate}&media_type=image";

            var response = await _httpClient.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var searchResponse = JsonConvert.DeserializeObject<SearchResponse>(content);

                var photos = new List<PhotoItem>();
                foreach (var item in searchResponse.Collection.Items)
                {
                    photos.Add(new PhotoItem
                    {
                        Id = item.Data[0].NasaId,
                        ImgSrc = item.Links[0].Href
                    });
                }

                return photos;
            }
            else
            {
                throw new Exception($"Failed to retrieve photos. Status code: {response.StatusCode}");
            }
        }
        public class SearchResponse
        {
            public Collection Collection { get; set; }
        }

        public class Collection
        {
            public List<Item> Items { get; set; }
        }

        public class Item
        {
            public List<DataItem> Data { get; set; }
            public List<Link> Links { get; set; }
        }
        public class DataItem
        {
            public string NasaId { get; set; }
        }

        public class Link
        {
            public string Href { get; set; }
        }
    }
}
