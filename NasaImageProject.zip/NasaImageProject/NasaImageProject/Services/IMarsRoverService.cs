﻿using NasaImageProject.Model;

namespace NasaImageProject.Services
{
    public interface IMarsRoverService
    {
        Task<List<PhotoItem>> GetPhotosByDateAsync(DateTime date);
    }
}
