﻿namespace NasaImageProject.Model
{
    public class PhotoItem
    {
        public string Id { get; set; }
        public string ImgSrc { get; set; }
    }
}
